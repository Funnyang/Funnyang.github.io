#!/usr/bin/env bash
#  anki.sh
#  Created by cdpath on 2018/4/19.
#  Copyright © 2018 cdpath. All rights reserved.

#set -xeuo pipefail


## PopClip Env
entry=${POPCLIP_TEXT:-debug}
safe_entry=${POPCLIP_URLENCODED_TEXT:-debug}
target_deck=${POPCLIP_OPTION_TARGET_DECK:-Default}
note_type=${POPCLIP_OPTION_NOTE_TYPE:-Basic}
back_field=${POPCLIP_OPTION_BACK_FIELD:-Back}
tag=${POPCLIP_OPTION_TAG:-debug}
app_tag=${POPCLIP_APP_NAME// /_} # replace spaces with underscore


## cocoaDialog
dialog() {
    ./dialog/Contents/MacOS/cocoaDialog bubble \
    --title "$1" \
    --text "$2" \
    --timeout "$3" \
    --icon-file anki.png
}

## AnkiConnect
gen_post_data()
{
    cat <<EOF
{
  "action": "guiAddCards",
  "version": 5,
  "params": {
    "note": {
      "fields": {
        "$back_field": "$entry"
      },
      "options": {
            "closeAfterAdding": true
      },
      "modelName": "$note_type",
      "deckName": "$target_deck",
      "tags": [
        "$tag",
        "$app_tag"
      ]
    }
  }
}
EOF
}

check_result()
{
    local resp=$1
    if [[ $resp != *'"error": null'* ]]; then
        if [[ $resp = "null" ]]; then
            msg="Invalid post data for AnkiConnect"
        else
            msg=$(echo "$resp" | perl -pe 's/^.*?(?<="error": ")(.*?[^\\])(?=[\."]).*?$/$1/' | sed -e 's/^"//' -e 's/"$//')
        fi
        if [[ -z "$resp" ]]; then
            msg="Did you open anki?"
        fi
        dialog "AnkiConnect" "$msg" 5
    fi
}


## main
main()
{
    payload=$(gen_post_data)
    res=$(curl -sX POST -d "$payload" "localhost:8765")
    check_result "$res"
}


main

